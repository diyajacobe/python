str1= input("enter the first string")
str2=input("enter the second string")
a=str2[0]+str1[1:]
b=str1[0]+str2[1:]
print(a+b)