d1={"a",100,"b",200}
d2={"x",300,"y",300}
d= d1.copy()
d.update(d2)
print("merged dictionary",d)