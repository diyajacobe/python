str1 = input("enter the string")
a = str1[-1]
b = str1[1:-1]
c = str1[0]
print(a+b+c)