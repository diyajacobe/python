colorlist1={"blue","red","green"}
colorlist2={"white","blue","black"}
newlist=colorlist1.difference(colorlist2)
print(newlist)