filename = input ("enter the filename" )
f = filename.split(".")
print("the extension of file is " +f[-1])
