color = input("enter some color")
n=color.split(",")
print("first color : ",n[-1])
print("last color:",n[0])
