def disp1(name):
    print("Hello, "+name)
person2={"name":"Aiswarya","Age":21,"Country":"India"}
