import rect,square
rect.rectangle(5,7)
square.square1(5)