def rectangle(l,b):
    area=l*b
    print("area of rectangle",+area)