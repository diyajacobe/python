from pack1 import f,f2
l=int(input("enter the length"))
b=int(input("enter the breadth"))
f.rectangle(l,b)
n=int(input("enter the side"))
f2.square1(n)