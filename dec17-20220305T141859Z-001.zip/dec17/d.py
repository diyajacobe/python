import d2
d2.disp1("Aiswarya")
a=d2.person2["Age"]
print(a)