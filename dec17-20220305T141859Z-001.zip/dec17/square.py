def square1(n):
    area=n*n
    print("area of square",+area)

