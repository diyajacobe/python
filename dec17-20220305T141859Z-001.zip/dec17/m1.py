def disp(name):
    print("hello,"+ name)