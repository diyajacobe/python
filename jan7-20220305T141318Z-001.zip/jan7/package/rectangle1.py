def rect(l,b):
 a=l*b
 print("the area of rectangle,",+a)