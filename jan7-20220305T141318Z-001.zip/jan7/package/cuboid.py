def cuboid(l1, b1, h1):
    a = 2 * (l1 * b1) + 2 * (b1 * h1) + 2 * (h1 * l1)
    print("the area of cuboid,", +a)