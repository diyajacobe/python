def circle(r):
 a=3.14*r*r
 print("the area of circle,",+a)