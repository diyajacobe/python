def sphere(r1):
 a=4*3.14*r1*r1
 print("the area of circle,",+a)