class rectangle:
    def __init__(self,l,b):
        self.length=l
        self.breadth=b
    def area(self):
        return(self.length*self.breadth)
    def compare(self,obj):
        if(self.area()==obj.area()):
            print("values are equal")
        else:
            print("not equal")
x1=rectangle(2,2)
x2=rectangle(4,2)
x1.compare(x2)
